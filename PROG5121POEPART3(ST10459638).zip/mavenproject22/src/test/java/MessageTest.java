/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author christopheredwardlinington
 */

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class MessageTest {

    @Test 
        void testChecktheIDforMessage_Success() {
        Message message = new Message();
        message.settheIDforMessage("1234567890"); // 10 characters
        assertTrue(message.checkIDforMessage(), "Message ID should be valid (10 characters)");
    }

    @Test
    void testChecktheIDforMessage_Failure_TooLong() {
        Message message = new Message();
        message.settheIDforMessage("12345678901"); // 11 characters
        assertFalse(message.checkIDforMessage(), "Message ID should be invalid (more than 10 characters)");
    }

    @Test
    void testChecktheIDforMessage_Failure_Null() {
        Message message = new Message();
        message.settheIDforMessage(null);
        assertFalse(message.checkIDforMessage(), "Message ID should be invalid (null)");
    }

    @Test
    void testChecktheIDforMessage_Failure_Empty() {
        Message message = new Message();
        message.settheIDforMessage("");
        assertFalse(message.checkIDforMessage(), "Message ID should be invalid (empty)");
    }

    @Test
    void testCheckCellofRecipient_Success_Example1() {
        Message message = new Message();
        message.setRecipient("+27718693002"); // Valid example from spec (12 digits after +)
        assertTrue(message.checkCellofRecipient(), "Recipient cell should be valid (example 1)");
    }

    @Test
    void testCheckCellofRecipient_Success_MinLength() {
        Message message = new Message();
        message.setRecipient("+123456789"); // 9 digits after + (min allowed by my interpretation)
        assertTrue(message.checkCellofRecipient(), "Recipient cell should be valid (min length)");
    }

    @Test
    void testCheckCellofRecipient_Success_MaxLength() {
        Message message = new Message();
        message.setRecipient("+123456789012345"); // 15 digits after + (max allowed by my interpretation)
        assertTrue(message.checkCellofRecipient(), "Recipient cell should be valid (max length)");
    }


    @Test
    void testCheckCellofRecipient_Failure_NoPlus() {
        Message message = new Message();
        message.setRecipient("27718693002"); // Missing '+'
        assertFalse(message.checkCellofRecipient(), "Recipient cell should be invalid (no international code)");
    }

    @Test
    void testCheckCellofRecipient_Failure_TooShort() {
        Message message = new Message();
        message.setRecipient("+12345678"); // 8 digits after +
        assertFalse(message.checkCellofRecipient(), "Recipient cell should be invalid (too short)");
    }

    @Test
    void testCheckCellofRecipient_Failure_TooLong() {
        Message message = new Message();
        message.setRecipient("+1234567890123456"); // 16 digits after +
        assertFalse(message.checkCellofRecipient(), "Recipient cell should be invalid (too long)");
    }

    @Test
    void testCheckCellofRecipient_Failure_NonDigits() {
        Message message = new Message();
        message.setRecipient("+2771869300A"); // Contains non-digit
        assertFalse(message.checkCellofRecipient(), "Recipient cell should be invalid (contains non-digits)");
    }

    @Test
    void testCreateHashofMessage_Success_TwoWords() {
        Message message = new Message();
        message.settheIDforMessage("1234567890");
        message.setMessageSentNum(5);
        message.setContentofMessage("Hello World");
        assertEquals("12:5:HELLOWORLD", message.createHashofMessage(), "Message hash for two words");
    }

    @Test
    void testCreateHashofMessage_Success_OneWord() {
        Message message = new Message();
        message.settheIDforMessage("0000000001");
        message.setMessageSentNum(1);
        message.setContentofMessage("Thanks");
        assertEquals("00:1:THANKSTHANKS", message.createHashofMessage(), "Message hash for one word");
    }

    @Test
    void testCreateHashofMessage_Success_MultipleWords() {
        Message message = new Message();
        message.settheIDforMessage("9876543210");
        message.setMessageSentNum(10);
        message.setContentofMessage("This is a test message");
        assertEquals("98:10:THISMESSAGE", message.createHashofMessage(), "Message hash for multiple words");
    }

    @Test
    void testCreateHashofMessage_Success_SpecialCharactersInMessage() {
        Message message = new Message();
        message.settheIDforMessage("5555555555");
        message.setMessageSentNum(3);
        message.setContentofMessage("Hello, how are you today?");
        assertEquals("55:3:HELLOTODAY?", message.createHashofMessage(), "Message hash with special characters");
    }


    @Test
    void testCreateHashofMessage_Failure_ShortMessageID() {
        Message message = new Message();
        message.settheIDforMessage("1");
        message.setMessageSentNum(1);
        message.setContentofMessage("Hi");
        assertEquals("ERROR: Invalid Message ID", message.createHashofMessage(), "Message hash for short ID");
    }
    
    @Test
   void testCheckIDforMessage_Valid() {
       Message message = new Message();
       message.settheIDforMessage("1234567890"); // 10 characters
       assertTrue(message.checkIDforMessage(), "Valid ID should return true");
   }

   @Test
   void testCheckIDforMessage_TooLong() {
       Message message = new Message();
       message.settheIDforMessage("12345678901"); // 11 characters
       assertFalse(message.checkIDforMessage(), "ID > 10 chars should return false");
   }

   @Test
   void testCheckIDforMessage_Null() {
       Message message = new Message();
       message.settheIDforMessage(null);
       assertFalse(message.checkIDforMessage(), "Null ID should return false");
   }

   @Test
   void testCheckIDforMessage_Empty() {
       Message message = new Message();
       message.settheIDforMessage("");
       assertFalse(message.checkIDforMessage(), "Empty ID should return false");
   }

   @Test
   void testCheckCellofRecipient_Valid() {
       Message message = new Message();
       message.setRecipient("+27712345678"); // Valid example (13 chars total, 12 digits after +)
       assertTrue(message.checkCellofRecipient(), "Valid recipient should be true");
   }

   @Test
   void testCheckCellofRecipien_NoPlus() {
       Message message = new Message();
       message.setRecipient("27712345678"); // No '+'
       assertFalse(message.checkCellofRecipient(), "Recipient without '+' should be false");
   }

   @Test
   void testCheckCellofRecipien_TooShortDigits() {
       Message message = new Message();
       message.setRecipient("+271234"); // Too short digits (less than 9 after +)
       assertFalse(message.checkCellofRecipient(), "Too short recipient digits should be false");
   }
   
   @Test
   void testCheckCellofRecipien_TooLongDigits() {
       Message message = new Message();
       message.setRecipient("+271234567890123456"); // Too long digits (more than 15 after +)
       assertFalse(message.checkCellofRecipient(), "Too long recipient digits should be false");
   }

   @Test
   void testCheckCellofRecipien_NonDigitsAfterPlus() {
       Message message = new Message();
       message.setRecipient("+277123456A8"); // Non-digit character
       assertFalse(message.checkCellofRecipient(), "Recipient with non-digits after '+' should be false");
   }

   @Test
   void testCreateHashofMessage_Standard() {
       Message message = new Message();
       message.settheIDforMessage("AB12345678");
       message.setMessageSentNum(5);
       message.setContentofMessage("Hello World this is a test message");
       String expectedHash = "AB:5:HELLOWORLD";
       assertEquals(expectedHash, message.createHashofMessage(), "Hash should be correctly generated for standard case");
   }

   @Test
   void testCreateHashofMessage_SingleWord() {
       Message message = new Message();
       message.settheIDforMessage("XY98765432");
       message.setMessageSentNum(1);
       message.setContentofMessage("Greetings");
       String expectedHash = "XY:1:GREETINGSGREETINGS"; // First and last word are the same, concatenated
       assertEquals(expectedHash, message.createHashofMessage(), "Hash should handle single word content");
   }

   @Test
   void testCreateHashofMessage_SpecialCharsInWords() {
       Message message = new Message();
       message.settheIDforMessage("0123456789");
       message.setMessageSentNum(0);
       message.setContentofMessage("First!@#word last$$word");
       String expectedHash = "01:0:FIRSTLAST"; // Special chars removed, uppercase
       assertEquals(expectedHash, message.createHashofMessage(), "Hash should remove special characters from words");
   }
   
   @Test
   void testCreateHashofMessage_MessageIDTooShort() {
       Message message = new Message();
       message.settheIDforMessage("A"); // Too short (less than 2 chars)
       message.setMessageSentNum(0);
       message.setContentofMessage("Any message content");
       assertEquals("ERROR: Invalid Message ID", message.createHashofMessage(), "Should return error for message ID less than 2 chars");
   }

   @Test
   void testCreateHashofMessage_NullMessageContent() {
       Message message = new Message();
       message.settheIDforMessage("1234567890");
       message.setMessageSentNum(2);
       message.setContentofMessage(null); // Null content
       String expectedHash = "12:2:"; // As first and last words would be empty
       assertEquals(expectedHash, message.createHashofMessage(), "Hash should handle null message content gracefully");
   }

   @Test
   void testCreateHashofMessage_EmptyMessageContent() {
       Message message = new Message();
       message.settheIDforMessage("1234567890");
       message.setMessageSentNum(3);
       message.setContentofMessage("   "); // Empty or whitespace content
       String expectedHash = "12:3:"; // As first and last words would be empty
       assertEquals(expectedHash, message.createHashofMessage(), "Hash should handle empty message content gracefully");
   }
    
    
}

/*
 * References:
 * OpenAI (2025) ChatGPT [Online]. Available at: https://chat.openai.com (Accessed: 25 June 2025).
 * Google (2025) Gemini [Online]. Available at: https://gemini.google.com (Accessed: 25 June 2025).
 */



