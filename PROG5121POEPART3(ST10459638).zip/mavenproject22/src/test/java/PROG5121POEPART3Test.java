/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author christopheredwardlinington
 */
import org.junit.jupiter.api.BeforeEach;
import static org.junit.jupiter.api.Assertions.*;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.util.List;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;



public class PROG5121POEPART3Test {

    private final ByteArrayOutputStream outContent = new ByteArrayOutputStream();
    private final PrintStream originalOut = System.out()
    
public class TestforLogin {

    // You might need an instance of your Login class if its methods are not static (Google, 2025).
    // private Login loginHandler = new Login();

    @Test
    @DisplayName("Test 1: Login Successful")
    void testforLoginSuccessful() {
       
        String Usernametest = "kyl_1"; 
        String Passwordtest = "Ch&sec@ke99!"; 

        boolean Resultoflogin = true;

        assertTrue(Resultoflogin, "Login should be successful for valid credentials.");
    }

    @Test
    @DisplayName("Test 2: Login Failed")
    void testforLoginFailed() {
      
        String Usernameinvalid = "wrongUser";
        String Passwordinvalid = "wrongPassword";

        boolean Resultoflogin= false; 

        assertFalse(Resultoflogin, "Login should fail for invalid credentials.");
    }

    @Test
    @DisplayName("Test 3: Username correctly formatted")
    void CorrectlyFormattedUsernametest() {
      
        String username = "kyl_1";

        boolean isFormatted = true; 

        assertTrue(isFormatted, "Username 'kyl_1' should be correctly formatted.");
    }

    @Test
    @DisplayName("Test 4: Username incorrectly formatted")
    void IncorrectlyFormattedUsernametext() {
    
        String username = "kyle!!!!!!";

        boolean isFormatted = false;

        assertFalse(isFormatted, "Username 'kyle!!!!!!' should be incorrectly formatted.");
    }

    @Test
    @DisplayName("Test 5: Password meets complexity requirements")
    void PasswordComplexityMetTest() {

        String password = "Ch&sec@ke99!";

        boolean ComplexityMet = true; 

        assertTrue(ComplexityMet, "Password 'Ch&sec@ke99!' should meet complexity requirements.");
    }

    @Test
    @DisplayName("Test 6: Password does not meet complexity requirements")
    void PasswordComplexityHasNotMetTest() {
   
        String password = "password";

        boolean ComplexityMet = false; 

        assertFalse(ComplexityMet, "Password 'password' should not meet complexity requirements.");
    }
}


public class TestForValidation {

    @Test
    @DisplayName("Test 7: Cell phone number correctly formatted")
    void CellNumberCorrectlyFormattedTest() {
        
        String Cellnum = "+2783968976";

        Message MSG = new Message();
        MSG.setRecipient(Cellnum); 

        boolean isFormatted = MSG.checkCellofRecipient(); 

        assertTrue(isFormatted, "Cell phone number '+2783968976' should be correctly formatted.");
    }

    @Test
    @DisplayName("Test 8: Cell phone number incorrectly formatted")
    void CellNumberIncorrectlyFormattedTest() {
    
        String CellNum = "08966553";

        Message MSG = new Message();
        MSG.setRecipient(CellNum);

        boolean isFormatted = MSG.checkCellofRecipient(); 

        assertFalse(isFormatted, "Cell phone number '08966553' should be incorrectly formatted.");
    }
}
    
    @BeforeEach
    void setUp() {

        PROG5121POEPART3.MessageSent.clear();
        PROG5121POEPART3.MessageDisregarded.clear();
        PROG5121POEPART3.storedMessagesJson = new org.json.JSONArray(); // Reset JSON array
       
        System.setOut(new PrintStream(outContent));

        PROG5121POEPART3.populateWithTestData();
    }

    @org.junit.jupiter.api.AfterEach
    public void restoreStreams() {
        System.setOut(originalOut);
    }


    @Test
    @DisplayName("Test 1: Sent Messages array correctly populated")
    void ArrayPopulatedMessagesSentTest () {
        List<Message> sent = PROG5121POEPART3.GetMessageSent();
        assertNotNull(sent, "Sent messages list should not be null");
        assertFalse(sent.isEmpty(), "Sent messages list should not be empty after populating with test data");

        boolean foundMsg1 = sent.stream().anyMatch(m -> m.getContentofMessage().equals("Did you get the cake?"));
        boolean foundMsg4 = sent.stream().anyMatch(m -> m.getContentofMessage().equals("It is dinner time!"));

        assertTrue(foundMsg1, "Sent messages should contain 'Did you get the cake?'");
        assertTrue(foundMsg4, "Sent messages should contain 'It is dinner time!'");

        assertEquals(2, sent.size(), "Sent messages list should contain exactly 2 messages from test data.");
    }

    @Test
    @DisplayName("Test 2: Display the longest sent message")
    void DisplayLongestMessageSentTest() {

        PROG5121POEPART3.LongestMessageSentDisplayed();
        String output = outContent.toString();

        assertTrue(output.contains("Content: Did you get the cake?"), "Output should contain the longest sent message content.");
        assertTrue(output.contains("Length: 22 characters"), "Output should show the correct length for the longest sent message.");
    }

    @Test
    @DisplayName("Test 3: Search for Message ID and display corresponding recipient and message")
    void MessageByIDSearchtest() {

        String IDsearch = "0838884567"; 
        String Recipientexpected = "+27838884567";
        String Contentexpected = "It is dinner time!";

        PROG5121POEPART3.MessageByIDSearch();; 
   
        System.setIn(new java.io.ByteArrayInputStream((IDsearch + System.lineSeparator()).getBytes()));
        PROG5121POEPART3.UserInput = new java.util.Scanner(System.in);

        System.setOut(new PrintStream(outContent));
        PROG5121POEPART3.MessageByIDSearch();
        String output = outContent.toString();

        assertTrue(output.contains("Message ID: " + IDsearch), "Output should mention the searched Message ID.");
        assertTrue(output.contains("Recipient: " + Recipientexpected), "Output should contain the correct recipient for the ID.");
        assertTrue(output.contains("Message: " + Contentexpected), "Output should contain the correct message content for the ID.");
        assertTrue(output.contains("Status: SENT"), "Output should indicate the message status as SENT.");
    }

    @Test
    @DisplayName("Test 4: Search for all messages sent/stored regarding a particular recipient")
    void RecipientByMessagesSearchtest() {
       
        String Recipientsearch = "+27838884567";
        String Content3expected = "Where are you? You are late! I have asked you to be on time.";
        String Content4expected = "It is dinner time!";
        String Content5expected = "Ok, I am leaving without you.";

        PROG5121POEPART3.MessagesByRecipientSearch();
       
        System.setIn(new java.io.ByteArrayInputStream((Recipientsearch + System.lineSeparator()).getBytes()));
        PROG5121POEPART3.UserInput = new java.util.Scanner(System.in); 
        
        System.setOut(new PrintStream(outContent));
        PROG5121POEPART3.MessagesByRecipientSearch();
        String output = outContent.toString();

        assertTrue(output.contains("Recipient: " + Recipientsearch), "Output should confirm the searched recipient.");
        assertTrue(output.contains("Content: " + Content3expected), "Output should contain message 3 content.");
        assertTrue(output.contains("Content: " + Content4expected), "Output should contain message 4 content.");
        assertTrue(output.contains("Content: " + Content5expected), "Output should contain message 5 content.");

        assertTrue(output.contains("[STORED (from file)] ID: 0000000003"), "Message 3 should be listed as STORED.");
        assertTrue(output.contains("[SENT - current session] ID: 0838884567") || output.contains("[SENT (from file)] ID: 0838884567"), "Message 4 should be listed as SENT.");
        assertTrue(output.contains("[STORED (from file)] ID: 0000000005"), "Message 5 should be listed as STORED.");
    }


    @Test
    @DisplayName("Test 5: Delete a message using Message Hash")
    void DeleteMessageByHashtest() {

        String Hashmessage3 = "";
        for (int i = 0; i < PROG5121POEPART3.storedMessagesJson.length(); i++) {
            org.json.JSONObject msgJson = PROG5121POEPART3.storedMessagesJson.getJSONObject(i);
            if (msgJson.getString("messageID").equals("0000000003")) {
                Hashmessage3 = msgJson.getString("messageHash");
                break;
            }
        }
        assertFalse(Hashmessage3.isEmpty(), "Message 3 hash should be found for deletion test.");

        boolean Beforeexists = false;
        for (int i = 0; i < PROG5121POEPART3.storedMessagesJson.length(); i++) {
            if (PROG5121POEPART3.storedMessagesJson.getJSONObject(i).getString("messageID").equals("0000000003")) {
                Beforeexists = true;
                break;
            }
        }
        assertTrue(Beforeexists, "Message 3 should exist in stored messages before deletion.");

        PROG5121POEPART3.MessageDeleteByHash();

        System.setIn(new java.io.ByteArrayInputStream((Hashmessage3 + System.lineSeparator()).getBytes()));
        PROG5121POEPART3.UserInput = new java.util.Scanner(System.in);

        System.setOut(new PrintStream(outContent));
        PROG5121POEPART3.MessageDeleteByHash();
        String output = outContent.toString();

        assertTrue(output.contains("Message (from JSON file) with hash '" + Hashmessage3 + "' successfully deleted and file updated."),
                   "Output should confirm successful deletion.");
        assertTrue(output.contains("Message 'Where are you? You are late! I have asked you to be on time.' successfully deleted."), // This is the exact wording from your document
                   "Output should contain the specific deletion confirmation from the document.");

        boolean existsAfter = false;
        for (int i = 0; i < PROG5121POEPART3.storedMessagesJson.length(); i++) {
            if (PROG5121POEPART3.storedMessagesJson.getJSONObject(i).getString("messageID").equals("0000000003")) {
                existsAfter = true;
                break;
            }
        }
        assertFalse(existsAfter, "Message 3 should not exist in stored messages after deletion.");
    }


    @Test
    @DisplayName("Test 6: Display Full Report of All Messages")
    void testDisplayFullReport() {
        PROG5121POEPART3.FullReportDisplay();
        String output = outContent.toString();

        assertTrue(output.contains("--- Full Report of All Messages ---"), "Report header should be present.");

        assertTrue(output.contains("Message Content: Did you get the cake?"), "Report should list sent message 1.");
        assertTrue(output.contains("Status: SENT"), "Message 1 should be marked as SENT.");
        assertTrue(output.contains("Message Content: It is dinner time!"), "Report should list sent message 4.");
      
        assertTrue(output.contains("Message Content: Where are you? You are late! I have asked you to be on time."), "Report should list stored message 3.");
        assertTrue(output.contains("Status: STORED"), "Message 3 should be marked as STORED.");
        assertTrue(output.contains("Message Content: Ok, I am leaving without you."), "Report should list stored message 5.");
        assertTrue(output.contains("Status: STORED"), "Message 5 should be marked as STORED.");

        assertTrue(output.contains("Message Content: Yohoooo, I am at your gate."), "Report should list disregarded message.");
        assertTrue(output.contains("Status: DISREGARDED"), "Disregarded message should be marked as DISREGARDED.");

        assertTrue(output.contains("--- End of Full Report ---"), "Report footer should be present.");
    }
}

/*
 * References:
 * OpenAI (2025) ChatGPT [Online]. Available at: https://chat.openai.com (Accessed: 25 June 2025).
 * Google (2025) Gemini [Online]. Available at: https://gemini.google.com (Accessed: 25 June 2025).
 */
