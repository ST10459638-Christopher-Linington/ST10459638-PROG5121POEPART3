import java.util.Objects;

//Main Class
public class Message {
    private String IDforMessage;
    private int MessageSentNum; // This now conceptually means 'order of message processed'
    private String Recipient;
    private String ContentofMessage;
    private String HashofMessage;
    private boolean isSent; // To track if the message was sent or stored/discarded

    //Message method
    public Message() {
        this.isSent = false;
    }

    // The Getter for MessageID
    public String gettheIDforMessage() {
        return IDforMessage;
    }

    // The Setter for MessageID
    public void settheIDforMessage(String IDforMessage) {
        this.IDforMessage = IDforMessage;
    }

    // The Getter for MessageSent
    public int getMessageSentNum() {
        return MessageSentNum;
    }

    // The Setter for MessageSent
    public void setMessageSentNum(int MessageSentNum) {
        this.MessageSentNum = MessageSentNum;
    }

    // The Getter for Recipient
    public String getRecipient() {
        return Recipient;
    }

     // The Setter for Recipient
    public void setRecipient(String recipient) {
        this.Recipient = recipient;
    }

    // The Getter for MessageSent
    public String getContentofMessage() {
        return ContentofMessage;
    }

    public void setContentofMessage(String ContentofMessage) {
        this.ContentofMessage = ContentofMessage;
    }

    // The Getter for MessageSent
    public String getHashofMessage() {
        return HashofMessage;
    }

    // The Setter for MessageHash
    public void setHashofMessage(String Hashofmessage) {
        this.HashofMessage= Hashofmessage;
    }

    // Boolean: isSent()
    public boolean isSent() {
        return isSent;
    }

    //Boolean: setSent()
    public void setSent(boolean sent) {
        isSent = sent;
    }

    // Boolean: checkMessageID()
    public boolean checkIDforMessage() {
        return IDforMessage != null && !IDforMessage.isEmpty() && IDforMessage.length() <= 10;
    }

    // Boolean: checkRecipientCell()
    public boolean checkCellofRecipient() {
        if (Recipient == null || !Recipient.startsWith("+")) {
            return false;
        }
        String digitsOnly = Recipient.substring(1); 
        
        if (!digitsOnly.matches("\\d+")) {
            return false;
        }
      
        return digitsOnly.length() >= 9 && digitsOnly.length() <= 15;
    }

    // String: createMessageHash()
    public String createHashofMessage() {
        if (IDforMessage == null || IDforMessage.length() < 2) {
            this.HashofMessage = "ERROR: Invalid Message ID";
            return this.HashofMessage;
        }
        String firstTwoID = IDforMessage.substring(0, 2);

        String firstWordProcessed = ""; // Will hold the first word processed
        String lastWordProcessed = "";  // Will hold the last word processed

        if (ContentofMessage != null && !ContentofMessage.trim().isEmpty()) {
         
            String[] words = ContentofMessage.trim().split("\\s+");

            if (words.length > 0) {
                
                firstWordProcessed = words[0].replaceAll("[^a-zA-Z0-9]", "");

                if (words.length > 1) {
                   
                    String rawLastWord = words[words.length - 1];
                    if (rawLastWord.endsWith("?")) {
                      
                        lastWordProcessed = rawLastWord.substring(0, rawLastWord.length() - 1).replaceAll("[^a-zA-Z0-9]", "") + "?";
                    } else {
                        
                        lastWordProcessed = rawLastWord.replaceAll("[^a-zA-Z0-9]", "");
                    }
                } else {
                    
                    String rawSingleWord = words[0];
                    if (rawSingleWord.endsWith("?")) {
                        lastWordProcessed = rawSingleWord.substring(0, rawSingleWord.length() - 1).replaceAll("[^a-zA-Z0-9]", "") + "?";
                    } else {
                        lastWordProcessed = rawSingleWord.replaceAll("[^a-zA-Z0-9]", "");
                    }
                    firstWordProcessed = lastWordProcessed; 
                }
            }
        }

        // Constructing the hash by concatenating the processed, uppercase first and last words
        this.HashofMessage = String.format("%s:%d:%s%s",
                firstTwoID,
                MessageSentNum,
                firstWordProcessed.toUpperCase(),
                lastWordProcessed.toUpperCase());
        return this.HashofMessage;
    }
}

/*
 * References:
 * OpenAI (2025) ChatGPT [Online]. Available at: https://chat.openai.com (Accessed: 25 June 2025).
 * Google (2025) Gemini [Online]. Available at: https://gemini.google.com (Accessed: 25 June 2025).
 */

