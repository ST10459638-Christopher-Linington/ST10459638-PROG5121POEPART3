import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import javax.swing.JOptionPane;
import java.util.Scanner; 
import java.util.function.Consumer;



public class PROG5121POEPART3 {
    
    

    
    
    public static JSONArray storedMessagesJson = new JSONArray(); // For holding messages in the JSON format (sent AND stored)
    public static final String JSON_FILE_PATH = "stored_messages.json"; // JSON file path
    static Scanner UserInput = new Scanner(System.in);

    // Arrays 
    static List<Message> MessageSent = new ArrayList<>(); // Contains all messages explicitly sent
    public static List<Message> MessageDisregarded = new ArrayList<>(); // Contains messages that were disregarded
    // "Stored Messages" requirement is covered by storedMessagesJson
    // Message objects contain the properties of Message Hash and Message ID

    public static int SumMessageSent = 0; // Sum total of all messages that user attempts to enter
    public static int CountMessage = 0; // Counts messages that are actually sent or stored (Message.numMessagesSent uses it)

    public static void main(String[] args) {
        String username = Usernamecapture();
        String password = Passwordcapture();
        String cellphonenumber = Cellphonenumcapture();

        // Steps for Verification 
        Usernameverification(username);
        Passwordverification(password);

        System.out.println("\nInputs accepted. Access granted!");

        System.out.println("Welcome to QuickChat.");
        loadMessageStored(); // JSON file is the place you load messages from
        StartofApplication();
    }

    // All the conditions that the User must adhere to in order to enter a Username.
    public static String Usernamecapture() {
        String username;
        while (true) {
            System.out.print("Enter a username: ");
            username = UserInput.nextLine();
            if (username.length() <= 5 && username.contains("_")) {
                System.out.println("Username successfully captured.");
                return username;
            } else {
                System.out.println("Username is not correctly formatted, please ensure that your username "
                        + "contains an underscore and is no more than five characters in length.");
            }
        }
    }

    // All the conditions that the User must adhere to in order to enter a password.
    public static String Passwordcapture() {
        String password;
        while (true) {
            System.out.print("Enter a password: ");
            password = UserInput.nextLine();

            boolean hasUpper = password.matches(".*[A-Z].*");
            boolean hasDigit = password.matches(".*[0-9].*");
            boolean hasSpecial = password.matches(".*[^a-zA-Z0-9].*");
            boolean longEnough = password.length() >= 8;

            if (longEnough && hasUpper && hasDigit && hasSpecial) {
                System.out.println("Password successfully captured.");
                return password;
            } else {
                System.out.println("Password is not correctly formatted, please ensure that password contains at least eight characters,"
                        + " a capital letter, a number and a special character. ");
            }
        }
    }

    // All the conditions that the User must adhere to in order to enter a Cellphonenumber.
    public static String Cellphonenumcapture() {
        String cellnum;
        while (true) {
            System.out.print("Enter your cellphone number: ");
            cellnum = UserInput.nextLine();
            if (cellnum.startsWith("+") && cellnum.substring(1).matches("\\d+") && cellnum.length() >= 10 && cellnum.length() <= 16) {
                System.out.println("Cell phone number successfully added.");
                return cellnum;
            } else {
                System.out.println("Cell phone number incorrectly formatted. It must start with '+' followed by 9-15 digits (e.g., +27XXXXXXXXX).");
            }
        }
    }

   
    // All the verifications that ensure that the entered Username is correctly formatted. 
    public static void Usernameverification(String correctUsername) {
        String UserInput2;
        while (true) {
            System.out.print("Please enter your username: ");
            UserInput2 = UserInput.nextLine();
            if (UserInput2.equals(correctUsername)) {
                break; 
            } else {
                System.out.println("The username you entered is incorrect, try again.");
            }
        }
    }

    // All the verifications that ensure that the entered Password is correctly formatted. 
    public static void Passwordverification(String correctPassword) {
        String UserInput3;
        while (true) {
            System.out.print("Please enter your password: ");
            UserInput3 = UserInput.nextLine();
            if (UserInput3.equals(correctPassword)) {
                System.out.println("Welcome, it is great to see you again.");
                break; 
            } else {
                System.out.println("Username or password incorrect, please try again.");
            }
        }
    }

  
    // The method that contains most of the called methods that start this section of code
    public static void StartofApplication() {
        int UserChoice;
        do {
            DisplaytheMenu();
            UserChoice = getUserChoice();

            switch (UserChoice) {
                case 1:
                    MessageFlow();
                    break;
                case 2:
                    displaySenderAndRecipientOfAllSentMessages();
                    break;
                case 3:
                    LongestMessageSentDisplayed();
                    break;
                case 4:
                    MessageByIDSearch();
                    break;
                case 5:
                    MessagesByRecipientSearch();
                    break;
                case 6:
                    MessageDeleteByHash();
                    break;
                case 7:
                    FullReportDisplay();
                    break;
                case 8:
                    System.out.println("Exiting QuickChat. Goodbye!");
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        } while (UserChoice != 8);
    }

    // Displays Menu for us to choose acions.
    public static void DisplaytheMenu() {
        System.out.println("\n--- QuickChat Menu ---");
        System.out.println("1. Send Messages");
        System.out.println("2. Display Sender and Recipient of All Sent Messages");
        System.out.println("3. Display the Longest Sent Message");
        System.out.println("4. Search for a Message by ID");
        System.out.println("5. Search for Messages by Recipient");
        System.out.println("6. Delete a Message using Message Hash");
        System.out.println("7. Display Full Report of All Messages");
        System.out.println("8. Quit");
        System.out.print("Enter your choice: ");
    }

    // 
    public static int getUserChoice() {
        while (!UserInput.hasNextInt()) {
            System.out.println("Invalid input. Please enter a number.");
            UserInput.next(); 
            System.out.print("Enter your choice: ");
        }
        int choice = UserInput.nextInt();
        UserInput.nextLine(); 
        return choice;
    }

    // Contains all the requirements for messages to be sent, stored or discarded. 
    private static void MessageFlow() {
        System.out.print("How many messages do you wish to enter? ");
        int NumofMessagesEntered = 0;
        while (true) {
            try {
                NumofMessagesEntered  = Integer.parseInt(UserInput.nextLine());
                if (NumofMessagesEntered   <= 0) {
                    System.out.println("Please enter a positive number of messages.");
                } else {
                    break;
                }
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a number.");
            }
            System.out.print("How many messages do you wish to enter? ");
        }

        for (int i = 0; i <NumofMessagesEntered ; i++) {
            System.out.println("\n--- Entering Message " + (i + 1) + " ---");
            Message NewMessage = new Message(); 

            // Where we get the Recipient Number
            String NumforRecipient;
            do {
                System.out.print("Enter recipient cell number (e.g., +27123456789): ");
                NumforRecipient = UserInput.nextLine();
                NewMessage.setRecipient(NumforRecipient);
                if (!NewMessage.checkCellofRecipient()) {
                    System.out.println("Failure: Cell phone number is incorrectly formatted or does not contain an international code.");
                }
            } while (!NewMessage.checkCellofRecipient());

            // Where whe get the Message Content
            String ContentofMessage;
            do {
                System.out.print("Enter message (max 250 characters): ");
                ContentofMessage = UserInput.nextLine();
                NewMessage.setContentofMessage(ContentofMessage);
                if (ContentofMessage.length() > 250) {
                    System.out.println("Failure: Message exceeds 250 characters.");
                }
            } while (ContentofMessage.length() > 250);

            // Total Messages processed no matter the action (by increment) 
            SumMessageSent++; // This counts all the messages that are attempted to be entered
            
            // WHere the Message ID is made for all messages, no matter the action.
            NewMessage.settheIDforMessage(GenerateMessageID());

            // Ask User What They Want to Select. 
            System.out.println("\nMessage ready:");
            System.out.println("Message ID: " + NewMessage.gettheIDforMessage()); // Display generated ID
            System.out.println("Recipient: " + NewMessage.getRecipient());
            System.out.println("Message: " + NewMessage.getContentofMessage());
            System.out.println("\nChoose an action for this message:");
            System.out.println("1. Send Message");
            System.out.println("2. Disregard Message");
            System.out.println("3. Store Message to send later");
            System.out.print("Enter your choice: ");

            int ChoiceActionMessage = -1;
            while (true) {
                try {
                    ChoiceActionMessage = Integer.parseInt(UserInput.nextLine());
                    if (ChoiceActionMessage >= 1 && ChoiceActionMessage<= 3) break;
                    System.out.println("Invalid choice. Please enter 1, 2, or 3.");
                } catch (NumberFormatException e) {
                    System.out.println("Invalid input. Please enter a number.");
                }
            }

            switch (ChoiceActionMessage) {
                case 1:
                    CountMessage++; // Increment ONLY for sent/stored messages
                    NewMessage.setMessageSentNum(CountMessage); // Set this value for the hash
                    NewMessage.createHashofMessage(); // Create hash AFTER setting numMessagesSent
                    NewMessage.setSent(true);
                    MessageSent.add(NewMessage); // Add to in-memory list for 'sent'
                    StoretheMessage(NewMessage); // Store to JSON file (all messages that are not disregarded are stored)
                    JOptionPane.showMessageDialog(null,
                            "Message successfully sent.\n" +
                                    "MessageID: " + NewMessage.gettheIDforMessage() + "\n" +
                                    "Message Hash: " + NewMessage.getHashofMessage() + "\n" +
                                    "Recipient: " + NewMessage.getRecipient() + "\n" +
                                    "Message: " +NewMessage.getContentofMessage(),
                            "Message Sent", JOptionPane.INFORMATION_MESSAGE);
                    break;
                case 2:
                   MessageDisregarded.add(NewMessage); 
                    System.out.println("Message disregarded.");
              
                    NewMessage.setMessageSentNum(0); 
                    NewMessage.createHashofMessage(); 
                    break;
                case 3:
                    CountMessage++; // Increments for sent and stored messages only 
                    NewMessage.setMessageSentNum(CountMessage); 
                    NewMessage.createHashofMessage(); 
                    NewMessage.setSent(false); 
                    StoretheMessage(NewMessage); // This stores info ti JSON file
                    JOptionPane.showMessageDialog(null,
                            "Message successfully stored.\n" +
                                    "MessageID: " + NewMessage.gettheIDforMessage() + "\n" +
                                    "Message Hash: " + NewMessage.getHashofMessage() + "\n" +
                                    "Recipient: " + NewMessage.getRecipient() + "\n" +
                                    "Message: " + NewMessage.getContentofMessage(),
                            "Message Stored", JOptionPane.INFORMATION_MESSAGE);
                    break;
            }
       
            if (ChoiceActionMessage != 2) {
                System.out.println("Message Hash (final): " + NewMessage.getHashofMessage());
            } else {
                 System.out.println("Message Hash (for disregarded): " + NewMessage.getHashofMessage());
            }
        } 

        System.out.println("\nTotal number of messages entered: " + SumMessageSent);
        System.out.println("Total number of messages sent/stored: " + CountMessage);
    }

    // Generates 10 digits for the message ID
    public static String GenerateMessageID() {
        Random rand = new Random();
        long id = (long) (rand.nextDouble() * 9_000_000_000L) + 1_000_000_000L;
        return String.valueOf(id);
    }

    // Returns list of all messages sent
    public static List<Message> GetMessageSent() {
        return new ArrayList<>(MessageSent); 
    }

    // Returns list of total number of messages sent
    public static int returnSumMessageSent() {
        return SumMessageSent;
    }


    public static void loadMessageStored() {
        try {
            if (Files.exists(Paths.get(JSON_FILE_PATH))) {
                String content = new String(Files.readAllBytes(Paths.get(JSON_FILE_PATH)));
                if (!content.trim().isEmpty()) { // Check if content is not empty
                    storedMessagesJson = new JSONArray(content);
                    System.out.println("Stored messages loaded successfully from " + JSON_FILE_PATH);
                } else {
                    System.out.println("Stored messages file is empty. Initializing empty array.");
                    storedMessagesJson = new JSONArray();
                }
            } else {
                System.out.println("No existing messages file found. Creating new one on first store.");
                storedMessagesJson = new JSONArray();
            }
        } catch (IOException e) {
            System.err.println("Error reading JSON file: " + e.getMessage());
            storedMessagesJson = new JSONArray(); // Initialize to empty if read fails
        } catch (org.json.JSONException e) {
            System.err.println("Error parsing JSON file. File might be corrupted: " + e.getMessage());
            storedMessagesJson = new JSONArray(); // Re-initialize to an empty array
        }
    }

    public static void StoretheMessage(Message message) {
        JSONObject messageJson = new JSONObject();
        messageJson.put("messageID", message.gettheIDforMessage());
        messageJson.put("numMessagesSent", message.getMessageSentNum()); // This is now the message counter.
        messageJson.put("recipient", message.getRecipient());
        messageJson.put("messageContent", message.getContentofMessage());
        messageJson.put("messageHash", message.getHashofMessage());
        messageJson.put("isSent", message.isSent());

    
        boolean existsInJson = false;
        for (int i = 0; i < storedMessagesJson.length(); i++) {
            JSONObject existingMsg = storedMessagesJson.getJSONObject(i);
            if (existingMsg.getString("messageID").equals(message.gettheIDforMessage())) {
                storedMessagesJson.put(i, messageJson);
                existsInJson = true;
                break;
            }
        }
        if (!existsInJson) {
            storedMessagesJson.put(messageJson);
        }

        try (FileWriter file = new FileWriter(JSON_FILE_PATH)) {
            file.write(storedMessagesJson.toString(4)); // Pretty print
            file.flush();
            System.out.println("Messages saved to " + JSON_FILE_PATH);
        } catch (IOException e) {
            System.err.println("Error saving message to JSON file: " + e.getMessage());
        }
    }

    // Displays sender and recipients of all messages.
    public static void displaySenderAndRecipientOfAllSentMessages() {
        if (MessageSent.isEmpty()) {
            System.out.println("\nNo messages have been sent yet during this session.");
            return;
        }
        System.out.println("\n--- Sender and Recipient of All Sent Messages (Current Session) ---");
        System.out.println("Sender: Current User (You)");
        for (int i = 0; i < MessageSent.size(); i++) {
            Message msg = MessageSent.get(i);
            System.out.println("  Message " + (i + 1) + ":");
            System.out.println("    Recipient: " + msg.getRecipient());
            System.out.println("------------------------------------");
        }
        
        boolean foundSentFromJson = false;
        for (int i = 0; i < storedMessagesJson.length(); i++) {
            JSONObject msg = storedMessagesJson.getJSONObject(i);
            if (msg.getBoolean("isSent")) {
                if (!foundSentFromJson) {
                    System.out.println("\n--- Sender and Recipient of Previously Sent Messages (from file) ---");
                    foundSentFromJson = true;
                }
                System.out.println("  Message " + (i + 1) + ":");
                System.out.println("    Recipient: " + msg.getString("recipient"));
                System.out.println("------------------------------------");
            }
        }
        if (!foundSentFromJson && MessageSent.isEmpty()) {
            System.out.println("\nNo sent messages found.");
        }
    }

    // Show which message is the longest
    public static void LongestMessageSentDisplayed() {
        if (MessageSent.isEmpty() && storedMessagesJson.isEmpty()) {
            System.out.println("\nNo messages have been sent/stored yet to determine the longest.");
            return;
        }

        Message longestMessage = null;
        int maxLength = -1;

        // Checks in memory for sent messages
        for (Message msg : MessageSent) {
            if (msg.getContentofMessage() != null && msg.getContentofMessage().length() > maxLength) {
                maxLength = msg.getContentofMessage().length();
                longestMessage = msg;
            }
        }

        // Checks the stored messages in JSON (those that are marked as sent)
        for (int i = 0; i < storedMessagesJson.length(); i++) {
            JSONObject msgJson = storedMessagesJson.getJSONObject(i);
            if (msgJson.getBoolean("isSent")) { //Marked as sent messages
                String content = msgJson.getString("messageContent");
                if (content != null && content.length() > maxLength) {
                    maxLength = content.length();
       
                    Message tempMsg = new Message();
                    tempMsg.settheIDforMessage(msgJson.getString("messageID"));
                    tempMsg.setRecipient(msgJson.getString("recipient"));
                    tempMsg.setContentofMessage(content);
                    tempMsg.setHashofMessage(msgJson.getString("messageHash"));
                    tempMsg.setSent(true);
                    longestMessage = tempMsg;
                }
            }
        }


        if (longestMessage != null) {
            System.out.println("\n--- Longest Sent Message ---");
            System.out.println("  Message ID: " + longestMessage.gettheIDforMessage());
            System.out.println("  Recipient: " + longestMessage.getRecipient());
            System.out.println("  Content: " + longestMessage.getContentofMessage());
            System.out.println("  Length: " + maxLength + " characters");
            System.out.println("----------------------------");
        } else {
            System.out.println("\nCould not find a longest sent message (possibly all empty/null content or no sent messages).");
        }
    }
    
    
     public static void populateWithTestData() {
        System.out.println("\n--- Populating with Test Data ---");

       
        PROG5121POEPART3.CountMessage = 0;
        PROG5121POEPART3.SumMessageSent = 0;


        Consumer<Message> addTestDataMessage = (msg) -> {
            boolean alreadyExists = false;
            // Check if message is already sent (flagged)
            for (Message existingSentMsg : PROG5121POEPART3.MessageSent) {
                if (existingSentMsg.gettheIDforMessage().equals(msg.gettheIDforMessage())) {
                    alreadyExists = true;
                    break;
                }
            }
            // Checks if a message already exists in JSON (all types of messages)
            if (!alreadyExists) {
                for (int i = 0; i < PROG5121POEPART3.storedMessagesJson.length(); i++) {
                    JSONObject existingJsonMsg = PROG5121POEPART3.storedMessagesJson.getJSONObject(i);
                    if (existingJsonMsg.getString("messageID").equals(msg.gettheIDforMessage())) {
                        alreadyExists = true;
                        break;
                    }
                }
            }

            if (!alreadyExists) {
                if (msg.isSent()) {
                    PROG5121POEPART3.MessageSent.add(msg);
                } else if (msg.getContentofMessage().equals("Yohoooo, I am at your gate.")) { // Disregarded messages that are specific
                    PROG5121POEPART3.MessageDisregarded.add(msg);
                    System.out.println("  Added disregarded message to list: " + msg.getContentofMessage());
                    return; // Don't store messages that are disregarded into JSON as per ogrigianl logic
                }
                PROG5121POEPART3.StoretheMessage(msg); // All messages that are no disregarded as test data messages to JSON
                System.out.println("  Added test message: " + msg.getContentofMessage() + " (Flag: " + (msg.isSent() ? "Sent" : "Stored") + ")");
            } else {
                System.out.println("  Test message already exists (ID: " + msg.gettheIDforMessage() + "), skipping: " + msg.getContentofMessage());
            }
        };

        // Message of Test Data 1: (Sent)
        Message MSG1 = new Message();
        MSG1.setRecipient("+27834557896");
        MSG1.setContentofMessage("Did you get the cake?");
        MSG1.setSent(true);
        MSG1.settheIDforMessage("0000000001"); // Fixed ID for test data
        MSG1.setMessageSentNum(++PROG5121POEPART3.SumMessageSent); // Increment and assign
        MSG1.createHashofMessage();
        addTestDataMessage.accept(MSG1);
        PROG5121POEPART3.SumMessageSent++;

        // Message of Test Data 3: (Stored)
        Message MSG3 = new Message();
        MSG3.setRecipient("+27838884567");
        MSG3.setContentofMessage("Where are you? You are late! I have asked you to be on time.");
        MSG3.setSent(false); //Where it's Stored
        MSG3.settheIDforMessage("0000000003"); 
        MSG3.setMessageSentNum(++PROG5121POEPART3.SumMessageSent); 
        MSG3.createHashofMessage();
        addTestDataMessage.accept(MSG3);
        PROG5121POEPART3.SumMessageSent++;

        // Message of Test Data 4: (Sent)
        Message MSG4 = new Message();
        MSG4.setRecipient("+27838884567"); 
        MSG4.setContentofMessage("It is dinner time!");
        MSG4.setSent(true); //Where it's Stored
        MSG4.settheIDforMessage("0838884567"); 
        MSG4.setMessageSentNum(++PROG5121POEPART3.SumMessageSent); 
        MSG4.createHashofMessage();
        addTestDataMessage.accept(MSG4);
        PROG5121POEPART3.SumMessageSent++;

        // Messages of Test Data 5: (Stored)
        Message MSG5 = new Message();
        MSG5.setRecipient("+27838884567");
        MSG5.setContentofMessage("Ok, I am leaving without you.");
        MSG5.setSent(false); // Where it's Stored
        MSG5.settheIDforMessage("0000000005"); // Fixed ID for test data
        MSG5.setMessageSentNum(++PROG5121POEPART3.SumMessageSent); // Increment and assign
        MSG5.createHashofMessage();
        addTestDataMessage.accept(MSG5);
        PROG5121POEPART3.SumMessageSent++;

        // The example for disregarded message
        Message MSGDisregarded = new Message();
        MSGDisregarded.setRecipient("+27834484567");
        MSGDisregarded.setContentofMessage("Yohoooo, I am at your gate.");
        MSGDisregarded.setSent(false); // Not sent, not stored
        MSGDisregarded.settheIDforMessage("000000000D");
        MSGDisregarded.setMessageSentNum(0); 
        MSGDisregarded.createHashofMessage();
        addTestDataMessage.accept(MSGDisregarded);
        PROG5121POEPART3.SumMessageSent++;
        System.out.println("--- Test Data Population Complete ---");
    }
    

    // Message ID is sorched for and the displayed for the corresponding recipient and message.
    public static void MessageByIDSearch() {
        System.out.print("\nEnter the Message ID to search for: ");
        String searchID = UserInput.nextLine();
        boolean found = false;

        System.out.println("\n--- Search Results for Message ID: " + searchID + " ---");
        // sentMessages are searched (within memory)
        for (Message msg : MessageSent) {
            if (msg.gettheIDforMessage().equals(searchID)) {
                System.out.println("  Found in Sent Messages (current session):");
                System.out.println("    Recipient: " + msg.getRecipient());
                System.out.println("    Message: " + msg.getContentofMessage());
                System.out.println("    Hash: " + msg.getHashofMessage());
                found = true;
            }
        }

        // storedMessagesJson are checked for messages (from this file)
        for (int i = 0; i < storedMessagesJson.length(); i++) {
            JSONObject msgJson = storedMessagesJson.getJSONObject(i);
            if (msgJson.getString("messageID").equals(searchID)) {
                if (!found) {
                     System.out.println("  Found in Stored Messages (from file):");
                } else {
                     System.out.println("  (Also found in Stored Messages from file)");
                }
                System.out.println("    Recipient: " + msgJson.getString("recipient"));
                System.out.println("    Message: " + msgJson.getString("messageContent"));
                System.out.println("    Hash: " + msgJson.getString("messageHash"));
                System.out.println("    Status: " + (msgJson.getBoolean("isSent") ? "Sent" : "Stored"));
                found = true;
            }
        }

        if (!found) {
            System.out.println("  No message found with ID: " + searchID);
        }
        System.out.println("-----------------------------------");
    }

    // Search for messages sent to a specific recipient
    public static void MessagesByRecipientSearch() {
        System.out.print("\nEnter the Recipient Number to search for (e.g., +27123456789): ");
        String searchRecipient = UserInput.nextLine();
        boolean found = false;

        System.out.println("\n--- Search Results for Recipient: " + searchRecipient + " ---");
        
        for (Message msg : MessageSent) {
            if (msg.getRecipient().equals(searchRecipient)) {
                System.out.println("  [SENT - current session] ID: " + msg.gettheIDforMessage() + ", Content: " + msg.getContentofMessage());
                found = true;
            }
        }


        for (int i = 0; i < storedMessagesJson.length(); i++) {
            JSONObject msgJson = storedMessagesJson.getJSONObject(i);
            if (msgJson.getString("recipient").equals(searchRecipient)) {
                String status = msgJson.getBoolean("isSent") ? "SENT (from file)" : "STORED (from file)";
                System.out.println("  [" + status + "] ID: " + msgJson.getString("messageID") + ", Content: " + msgJson.getString("messageContent"));
                found = true;
            }
        }

        if (!found) {
            System.out.println("  No messages found for recipient: " + searchRecipient);
        }
        System.out.println("---------------------------------------");
    }

    // Messages are deleted by hash. 
    public static void MessageDeleteByHash() {
        System.out.print("\nEnter the Message Hash to delete: ");
        String searchHash = UserInput.nextLine();
        boolean deletedFromSent = false;
        boolean deletedFromJson = false;

        var sentIterator = MessageSent.iterator();
        while (sentIterator.hasNext()) {
            Message msg = sentIterator.next();
            if (msg.getHashofMessage().equals(searchHash)) {
                sentIterator.remove();
                deletedFromSent = true;
                System.out.println("Message (in-memory SENT list) with hash '" + searchHash + "' deleted.");
                break;
            }
        }

        // Delete and rewrite from JSON array
        JSONArray updatedStoredMessagesJson = new JSONArray();
        for (int i = 0; i < storedMessagesJson.length(); i++) {
            JSONObject msgJson = storedMessagesJson.getJSONObject(i);
            if (!msgJson.getString("messageHash").equals(searchHash)) {
                updatedStoredMessagesJson.put(msgJson);
            } else {
                deletedFromJson = true;
            }
        }

        if (deletedFromJson) {
            storedMessagesJson = updatedStoredMessagesJson; // Update the in-memory JSON array
            try (FileWriter file = new FileWriter(JSON_FILE_PATH)) {
                file.write(storedMessagesJson.toString(4));
                file.flush();
                System.out.println("Message (from JSON file) with hash '" + searchHash + "' successfully deleted and file updated.");
            } catch (IOException e) {
                System.err.println("Error rewriting JSON file after deletion: " + e.getMessage());
            }
        }

        if (!deletedFromSent && !deletedFromJson) {
            System.out.println("No message found with hash: " + searchHash + ". Nothing deleted.");
        }
        System.out.println("----------------------------------");
    }

    //Display full report of all messages
    public static void FullReportDisplay() {
        System.out.println("\n--- Full Report of All Messages ---");
        if (MessageSent.isEmpty() && storedMessagesJson.isEmpty()) {
            System.out.println("No messages have been processed yet.");
            System.out.println("-----------------------------------");
            return;
        }

        if (!MessageSent.isEmpty()) {
            System.out.println("\n-- Messages Sent During This Session --");
            for (int i = 0; i < MessageSent.size(); i++) {
                Message MSG = MessageSent.get(i);
                System.out.println("  Message " + (i + 1) + " (In-Memory):");
                System.out.println("    Message ID: " + MSG.gettheIDforMessage());
                System.out.println("    Recipient: " + MSG.getRecipient());
                System.out.println("    Message Content: " + MSG.getContentofMessage());
                System.out.println("    Message Hash: " + MSG.getHashofMessage());
                System.out.println("    Status: SENT");
                System.out.println("  ---------------------------------");
            }
        } else {
             System.out.println("\n-- No messages sent during this session --");
        }

        if (!storedMessagesJson.isEmpty()) {
            System.out.println("\n-- Messages from Stored JSON File --");
            for (int i = 0; i < storedMessagesJson.length(); i++) {
                JSONObject msg = storedMessagesJson.getJSONObject(i);
                System.out.println("  Message " + (i + 1) + " (From File):");
                System.out.println("    Message ID: " + msg.getString("messageID"));
                System.out.println("    Recipient: " + msg.getString("recipient"));
                System.out.println("    Message Content: " + msg.getString("messageContent"));
                System.out.println("    Message Hash: " + msg.getString("messageHash"));
                System.out.println("    Status: " + (msg.getBoolean("isSent") ? "SENT" : "STORED"));
                System.out.println("  ---------------------------------");
            }
        } else {
             System.out.println("\n-- No messages found in stored JSON file --");
        }

        System.out.println("\n--- End of Full Report ---");
    }

    // Returns a list of all disregarded messages.
    public static List<Message> getMessageDisregarded() {
        return new ArrayList<>(MessageDisregarded);
    }
}

/*
 * References:
 * OpenAI (2025) ChatGPT [Online]. Available at: https://chat.openai.com (Accessed: 25 June 2025).
 * Google (2025) Gemini [Online]. Available at: https://gemini.google.com (Accessed: 25 June 2025).
 */
